/**
 * LUXURY UZBEK WEDDING INVITATION (TAKLIFNOMA) ULTRA ENGINE
 */

// -------------------------------------------------------------
// TOP-LEVEL GLOBAL ENGINE FUNCTIONS (IMMEDIATE AVAILABILITY)
// -------------------------------------------------------------
// -------------------------------------------------------------
// TOP-LEVEL GLOBAL ENGINE FUNCTIONS (IMMEDIATE AVAILABILITY)
// -------------------------------------------------------------
window.createConfettiExplosion = function() {
  const count = 18;
  const icons = ['🌸', '✨', '💖', '🕊️', '👑', '🌟'];
  const fragment = document.createDocumentFragment();
  const elements = [];
  const startX = window.innerWidth / 2;
  const startY = window.innerHeight / 2;

  for (let i = 0; i < count; i++) {
    const el = document.createElement('div');
    el.textContent = icons[i % icons.length];
    el.style.cssText = `position:fixed;left:${startX + (Math.random() * 140 - 70)}px;top:${startY + (Math.random() * 80 - 40)}px;font-size:${Math.random() * 10 + 18}px;z-index:30000;pointer-events:none;will-change:transform,opacity;transition:transform 2.4s cubic-bezier(0.1, 0.8, 0.3, 1), opacity 2.4s ease;`;
    fragment.appendChild(el);
    elements.push(el);
  }
  document.body.appendChild(fragment);

  requestAnimationFrame(() => {
    elements.forEach(el => {
      const moveX = (Math.random() - 0.5) * 460;
      const moveY = Math.random() * 460 + 80;
      const rot = Math.random() * 360 - 180;
      el.style.transform = `translate3d(${moveX}px, ${moveY}px, 0) rotate(${rot}deg)`;
      el.style.opacity = '0';
    });
  });

  setTimeout(() => {
    elements.forEach(el => el.remove());
  }, 2500);
};

window.playAudioGlobal = function() {
  const bgAudio = document.getElementById('bg-audio');
  const audioToggleBtn = document.getElementById('audio-toggle-btn');
  if (bgAudio) {
    bgAudio.volume = 0.5;
    const playPromise = bgAudio.play();
    if (playPromise !== undefined) {
      playPromise.then(() => {
        if (audioToggleBtn) audioToggleBtn.classList.add('playing');
        if (window.setAudioPlayingState) window.setAudioPlayingState(true);
      }).catch((err) => {
        console.log('Audio autoplay prevented or failed, starting romantic synth fallback:', err);
        if (window.startRomanticSynth) window.startRomanticSynth();
      });
    }
  } else if (window.startRomanticSynth) {
    window.startRomanticSynth();
  }
};

window.openEnvelopeDirect = function(e) {
  if (e) {
    if (typeof e.stopPropagation === 'function') e.stopPropagation();
  }
  const env = document.getElementById('envelope-modal');
  if (env && !env.classList.contains('closed') && !env.classList.contains('closing')) {
    env.classList.add('closing');
    try { if (navigator.vibrate) navigator.vibrate(35); } catch(err) {}
    setTimeout(() => {
      env.classList.add('closed');
      env.classList.remove('closing');
      env.style.display = 'none';
    }, 450);
    try {
      window.createConfettiExplosion();
    } catch(err) {}
    try {
      window.playAudioGlobal();
    } catch(err) {}
  }
};

document.addEventListener('DOMContentLoaded', () => {

  // Default Wedding Config (Shahzod & Dilorom Demo)
  let config = {
    groom: 'Shahzod',
    bride: 'Dilorom',
    coupleNames: 'Shahzod & Dilorom',
    dateIso: '2026-10-17T17:00',
    dateFormatted: '2026-yil 17-oktabr · Shanba',
    venueName: '“Oq Saroy” Tantanalar Saroyi',
    venueAddress: 'Toshkent shahri, Yunusobod tumani, Amir Temur shoh ko\'chasi, 105-uy',
    mapUrl: 'https://yandex.com/maps/?text=Oq+Saroy+to\'yxonasi+Tashkent',
    cardNumber: '8600 1234 5678 9012',
    cardHolder: 'Shahzod Sh. (Uzcard/Humo)',
    schedule: [
      { time: '17:00', title: 'Mehmonlarni kutib olish', desc: 'To\'yxona fayerida tantanali kutib olish marosimi va musiqiy sadolar' },
      { time: '18:00', title: 'Kelin-kuyov kelishi & Nikoh', desc: 'Tantanali kirib kelish va nikoh to\'yining ochilishi' },
      { time: '19:00', title: 'Shohona Ziyofat & Qutlovlar', desc: 'Yaqinlar va mehmonlarning samimiy tilaklari hamda dasturxon' },
      { time: '21:00', title: 'Jonli Ijro, Raqs & Tort', desc: 'El suygan san\'atkorlar ijrosi va bayramona to\'y tortini kesish' }
    ]
  };

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // Cross-browser safe Date parser (Safari, iOS, Chrome, Firefox)
  function parseSafeDate(dateStr) {
    if (!dateStr) return new Date();
    if (dateStr instanceof Date) return dateStr;
    // Standard ISO string format parse
    let parsed = new Date(dateStr);
    if (!isNaN(parsed.getTime())) return parsed;
    
    // Convert YYYY-MM-DDTHH:mm to YYYY/MM/DD HH:mm for iOS Safari
    let formatted = dateStr.replace(/-/g, '/').replace('T', ' ');
    parsed = new Date(formatted);
    return isNaN(parsed.getTime()) ? new Date() : parsed;
  }

  // Helper to format ISO date string to Uzbek date text
  function formatUzbekDate(isoStr) {
    if (!isoStr) return config.dateFormatted;
    try {
      const d = parseSafeDate(isoStr);
      const year = d.getFullYear();
      const months = ['yanvar', 'fevral', 'mart', 'aprel', 'may', 'iyun', 'iyul', 'avgust', 'sentabr', 'oktabr', 'noyabr', 'dekabr'];
      const daysOfWeek = ['Yakshanba', 'Dushanba', 'Seshanba', 'Chorshanba', 'Payshanba', 'Juma', 'Shanba'];
      const day = d.getDate();
      const month = months[d.getMonth()];
      const dayName = daysOfWeek[d.getDay()];
      const hours = String(d.getHours()).padStart(2, '0');
      const mins = String(d.getMinutes()).padStart(2, '0');
      return `${year}-yil ${day}-${month} · ${dayName} (Soat ${hours}:${mins})`;
    } catch (e) {
      return isoStr;
    }
  }

  // -------------------------------------------------------------
  // READ URL PARAMS ONLY FOR CUSTOM DATA (NO LOCALSTORAGE)
  // Har bir foydalanuvchi faqat default namuna ko'radi.
  // Faqat URL params bo'lsa custom taklifnoma ko'rinadi.
  // Boshqalarning taklifnomalari bir-biriga ko'rinmaydi!
  // -------------------------------------------------------------
  const urlParams = new URLSearchParams(window.location.search);
  let isCustomUrl = false;
  
  if (urlParams.has('groom') || urlParams.has('bride')) {
    isCustomUrl = true;
    config.groom = urlParams.get('groom') || config.groom;
    config.bride = urlParams.get('bride') || config.bride;
    config.coupleNames = `${config.groom} & ${config.bride}`;
    if (urlParams.has('date')) config.dateIso = urlParams.get('date');
    if (urlParams.has('venue')) config.venueName = urlParams.get('venue');
    if (urlParams.has('address')) config.venueAddress = urlParams.get('address');
    if (urlParams.has('map')) config.mapUrl = urlParams.get('map');
    if (urlParams.has('card')) config.cardNumber = urlParams.get('card');
    if (urlParams.has('holder')) config.cardHolder = urlParams.get('holder');
    if (urlParams.has('sched')) {
      try {
        const rawSched = urlParams.get('sched');
        config.schedule = JSON.parse(rawSched);
      } catch (e) {
        try {
          config.schedule = JSON.parse(decodeURIComponent(urlParams.get('sched')));
        } catch (err) { console.error('Schedule parse error', err); }
      }
    }
  }
  // else: default config ishlatiladi (Shahzod & Dilorom namuna)
  
  // Eski localStorage ma'lumotlarini tozalash (privacy uchun)
  try { localStorage.removeItem('taklifnoma_user_config'); } catch(e) {}

  function renderTimeline(scheduleList) {
    const container = document.getElementById('timeline-container');
    if (!container) return;
    if (!scheduleList || !scheduleList.length) {
      container.innerHTML = '<p class="text-center text-muted" style="color: rgba(255,255,255,0.7); font-style: italic;">To\'y tartibi ko\'rsatilmagan</p>';
      return;
    }
    container.innerHTML = scheduleList.map(item => `
      <div class="timeline-item">
        <div class="timeline-time">${escapeHtml(item.time || '')}</div>
        <div class="timeline-dot"></div>
        <div class="timeline-content">
          <h3>${escapeHtml(item.title || '')}</h3>
          <p>${escapeHtml(item.desc || '')}</p>
        </div>
      </div>
    `).join('');
  }

  // Apply configuration to DOM elements
  function applyConfigToDOM() {
    config.dateFormatted = formatUzbekDate(config.dateIso);

    const envCoupleNames = document.getElementById('env-couple-names');
    const heroCoupleNames = document.getElementById('hero-couple-names');
    const msgCoupleNames = document.getElementById('msg-couple-names');
    const footerCoupleNames = document.getElementById('footer-couple-names');
    const heroDateText = document.getElementById('hero-date-text');
    const galleryCaptionCouple = document.getElementById('gallery-caption-couple');

    const venueNameText = document.getElementById('venue-name-text');
    const venueBadgeOverlay = document.getElementById('venue-badge-overlay');
    const venueAddressText = document.getElementById('venue-address-text');
    const venueTimeText = document.getElementById('venue-time-text');
    const btnYandexLink = document.getElementById('btn-yandex-link');
    const btnGoogleLink = document.getElementById('btn-google-link');
    const mapIframe = document.getElementById('map-iframe');

    const cardNumberText = document.getElementById('card-number-text');
    const cardHolderText = document.getElementById('card-holder-text');

    function formatCoupleHtml(g, b) {
      const groomStr = escapeHtml((g || 'Shahzod').trim());
      const brideStr = escapeHtml((b || 'Dilorom').trim());
      return `${groomStr} <span class="ampersand">&amp;</span> ${brideStr}`;
    }

    const coupleHtml = formatCoupleHtml(config.groom, config.bride);
    if (envCoupleNames) envCoupleNames.innerHTML = coupleHtml;
    if (heroCoupleNames) heroCoupleNames.innerHTML = coupleHtml;
    if (msgCoupleNames) msgCoupleNames.innerHTML = coupleHtml;
    if (footerCoupleNames) footerCoupleNames.innerHTML = coupleHtml;
    if (galleryCaptionCouple) galleryCaptionCouple.innerHTML = coupleHtml;
    if (heroDateText) heroDateText.textContent = config.dateFormatted;

    if (venueNameText) venueNameText.textContent = config.venueName;
    if (venueBadgeOverlay) venueBadgeOverlay.textContent = config.venueName.toUpperCase();
    if (venueAddressText) venueAddressText.textContent = '📍 ' + config.venueAddress;
    
    if (venueTimeText) {
      const d = parseSafeDate(config.dateIso);
      const months = ['yanvar', 'fevral', 'mart', 'aprel', 'may', 'iyun', 'iyul', 'avgust', 'sentabr', 'oktabr', 'noyabr', 'dekabr'];
      const monthName = months[d.getMonth()] || 'oktabr';
      const formattedShort = isNaN(d.getTime()) ? config.dateIso : `${d.getDate()}-${monthName}, ${d.getFullYear()}-yil`;
      const timeShort = isNaN(d.getTime()) ? '17:00' : `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
      venueTimeText.innerHTML = `🕒 Sana: <strong>${formattedShort}</strong> | Soat: <strong>${timeShort}</strong>`;
    }

    if (btnYandexLink) btnYandexLink.href = config.mapUrl || `https://yandex.com/maps/?text=${encodeURIComponent(config.venueName + ' ' + config.venueAddress)}`;
    if (btnGoogleLink) btnGoogleLink.href = (config.mapUrl && config.mapUrl.includes('google.com')) ? config.mapUrl : `https://maps.google.com/?q=${encodeURIComponent(config.venueName + ' ' + config.venueAddress)}`;

    // Dynamically update embedded Google Map iFrame
    if (mapIframe) {
      const targetSrc = (config.mapUrl && (config.mapUrl.includes('output=embed') || config.mapUrl.includes('embed')))
        ? config.mapUrl
        : `https://maps.google.com/maps?q=${encodeURIComponent(`${config.venueName}, ${config.venueAddress}`)}&t=&z=15&ie=UTF8&iwloc=&output=embed`;
      if (mapIframe.getAttribute('data-loaded-src') !== targetSrc) {
        mapIframe.setAttribute('data-loaded-src', targetSrc);
        setTimeout(() => { mapIframe.src = targetSrc; }, 30);
      }
    }

    if (cardNumberText) cardNumberText.textContent = config.cardNumber;
    if (cardHolderText) cardHolderText.textContent = config.cardHolder;

    renderTimeline(config.schedule);
  }

  applyConfigToDOM();

  // -------------------------------------------------------------
  // 1. OPENING ENVELOPE MODAL & AUDIO ACTIVATION
  // -------------------------------------------------------------
  const envelopeModal = document.getElementById('envelope-modal');
  const openInvitationBtn = document.getElementById('open-invitation-btn');
  const bgAudio = document.getElementById('bg-audio');
  const audioToggleBtn = document.getElementById('audio-toggle-btn');
  let isPlayingAudio = false;
  window.setAudioPlayingState = function(playing) {
    isPlayingAudio = playing;
    if (audioToggleBtn) {
      if (playing) audioToggleBtn.classList.add('playing');
      else audioToggleBtn.classList.remove('playing');
    }
  };

  // Web Audio Synthesizer fallback if mp3 is quiet/absent
  let audioCtx = null;
  let synthInterval = null;

  function startRomanticSynth() {
    if (audioCtx) return;
    try {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const notes = [261.63, 329.63, 392.00, 493.88, 523.25, 659.25];
      let idx = 0;
      synthInterval = setInterval(() => {
        if (!audioCtx || audioCtx.state !== 'running') return;
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(notes[idx % notes.length], audioCtx.currentTime);
        gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 1.8);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + 1.8);
        idx++;
      }, 700);
      window.setAudioPlayingState(true);
    } catch (e) {
      console.log('Web Audio Synth unavailable:', e);
    }
  }
  window.startRomanticSynth = startRomanticSynth;

  function playAudio() {
    window.playAudioGlobal();
  }

  function toggleAudio() {
    if (isPlayingAudio) {
      if (bgAudio) bgAudio.pause();
      if (audioCtx && audioCtx.state === 'running') audioCtx.suspend();
      window.setAudioPlayingState(false);
    } else {
      if (bgAudio && bgAudio.src) {
        bgAudio.volume = 0.5;
        bgAudio.play().then(() => {
          window.setAudioPlayingState(true);
        }).catch(() => {
          startRomanticSynth();
          window.setAudioPlayingState(true);
        });
      } else {
        startRomanticSynth();
        window.setAudioPlayingState(true);
      }
      if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
    }
  }

  function openEnvelope(e) {
    window.openEnvelopeDirect(e);
  }

  // Faqat dumaloq muhr bosilganda taklifnoma ochiladi
  if (openInvitationBtn) {
    openInvitationBtn.addEventListener('click', openEnvelope);
  }

  // Shaxsiy murojaat: ?guest=Ism  ->  "Hurmatli Ism!" + RSVP formasiga avtomatik yoziladi
  (function applyGuestName() {
    const guest = (urlParams.get('guest') || '').trim().slice(0, 60);
    if (!guest) return;
    const envGuest = document.getElementById('env-guest');
    if (envGuest) {
      envGuest.textContent = 'Hurmatli ' + guest + '!';
      envGuest.classList.remove('hidden');
    }
    const guestInput = document.getElementById('guest-name');
    if (guestInput && !guestInput.value) guestInput.value = guest;
  })();

  // Kalendarga qo'shish (.ics fayl yuklab olinadi)
  (function setupCalendarButton() {
    const btn = document.getElementById('add-calendar-btn');
    if (!btn) return;
    btn.addEventListener('click', () => {
      const m = String(config.dateIso || '').match(/(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/);
      if (!m) { showToast('⚠️ Sana noto\'g\'ri kiritilgan'); return; }
      // Toshkent vaqti (UTC+5) bo'yicha hisoblab, UTC ga o'tkazamiz
      const start = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4] - 5, +m[5]));
      const end = new Date(start.getTime() + 5 * 3600 * 1000);
      const fmt = (d) => d.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
      const esc = (s) => String(s || '').replace(/([,;\\])/g, '\\$1').replace(/\n/g, '\\n');
      const ics = [
        'BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Taklifnoma//UZ//',
        'BEGIN:VEVENT',
        'UID:' + start.getTime() + '@taklifnoma',
        'DTSTAMP:' + fmt(new Date()),
        'DTSTART:' + fmt(start),
        'DTEND:' + fmt(end),
        'SUMMARY:' + esc(config.coupleNames + ' — To\'y (Visol oqshomi)'),
        'LOCATION:' + esc(config.venueName + ', ' + config.venueAddress),
        'DESCRIPTION:' + esc('Sizni nikoh to\'yimizga taklif etamiz!'),
        'BEGIN:VALARM', 'TRIGGER:-P1D', 'ACTION:DISPLAY', 'DESCRIPTION:Ertaga to\'y!', 'END:VALARM',
        'END:VEVENT', 'END:VCALENDAR'
      ].join('\r\n');
      const blob = new Blob([ics], { type: 'text/calendar;charset=utf-8' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'toy-taklifnomasi.ics';
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
      showToast('🗓️ Kalendar fayli yuklab olindi');
    });
  })();

  if (audioToggleBtn) {
    audioToggleBtn.addEventListener('click', toggleAudio);
  }

  // -------------------------------------------------------------
  // 2. PARALLAX MOUSE MOTION FOR HERO SWAN BACKGROUND
  // -------------------------------------------------------------
  const heroSection = document.querySelector('.hero-section');
  const heroSwanImgs = document.querySelectorAll('.hero-swan-img');
  const heroContent = document.querySelector('.hero-content');

  if (heroSection) {
    heroSection.addEventListener('mousemove', (e) => {
      const { clientX, clientY } = e;
      const { innerWidth, innerHeight } = window;
      const moveX = (clientX - innerWidth / 2) / (innerWidth / 2);
      const moveY = (clientY - innerHeight / 2) / (innerHeight / 2);

      heroSwanImgs.forEach(img => {
        img.style.transform = `scale(1.08) translate(${moveX * 15}px, ${moveY * 15}px)`;
      });

      if (heroContent) {
        heroContent.style.transform = `translate(${-moveX * 10}px, ${-moveY * 10}px)`;
      }
    });

    heroSection.addEventListener('mouseleave', () => {
      heroSwanImgs.forEach(img => {
        img.style.transform = '';
      });
      if (heroContent) {
        heroContent.style.transform = '';
      }
    });
  }

  // -------------------------------------------------------------
  // 3. LIVE COUNTDOWN TIMER (KUN, SOAT, DAQIQA, SONIYA)
  // -------------------------------------------------------------
  const cdDays = document.getElementById('cd-days');
  const cdHours = document.getElementById('cd-hours');
  const cdMinutes = document.getElementById('cd-minutes');
  const cdSeconds = document.getElementById('cd-seconds');

  function updateCountdown() {
    const targetTime = parseSafeDate(config.dateIso).getTime();
    const now = new Date().getTime();
    const distance = targetTime - now;

    if (isNaN(distance) || distance <= 0) {
      if (cdDays) cdDays.textContent = '00';
      if (cdHours) cdHours.textContent = '00';
      if (cdMinutes) cdMinutes.textContent = '00';
      if (cdSeconds) cdSeconds.textContent = '00';
      return;
    }

    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((distance % (1000 * 60)) / 1000);

    if (cdDays) cdDays.textContent = days < 10 ? '0' + days : days;
    if (cdHours) cdHours.textContent = hours < 10 ? '0' + hours : hours;
    if (cdMinutes) cdMinutes.textContent = minutes < 10 ? '0' + minutes : minutes;
    if (cdSeconds) cdSeconds.textContent = seconds < 10 ? '0' + seconds : seconds;
  }

  updateCountdown();
  setInterval(updateCountdown, 1000);

  // -------------------------------------------------------------
  // 4. TOAST NOTIFICATIONS & CROSS-BROWSER CLIPBOARD COPY
  // -------------------------------------------------------------
  const toast = document.getElementById('toast-notification');
  const toastMsg = document.getElementById('toast-msg');

  function showToast(message) {
    if (!toast || !toastMsg) return;
    toastMsg.textContent = message;
    toast.classList.add('show');
    setTimeout(() => {
      toast.classList.remove('show');
    }, 3000);
  }

  function copyToClipboard(text, successMsg) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(() => {
        showToast(successMsg);
      }).catch(() => {
        fallbackCopyTextToClipboard(text, successMsg);
      });
    } else {
      fallbackCopyTextToClipboard(text, successMsg);
    }
  }

  function fallbackCopyTextToClipboard(text, successMsg) {
    const textArea = document.createElement("textarea");
    textArea.value = text;
    textArea.style.position = "fixed";
    textArea.style.left = "-9999px";
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    try {
      document.execCommand('copy');
      showToast(successMsg);
    } catch (err) {
      showToast('Nusxalandi: ' + text);
    }
    document.body.removeChild(textArea);
  }

  const copyAddressBtn = document.getElementById('copy-address-btn');
  if (copyAddressBtn) {
    copyAddressBtn.addEventListener('click', () => {
      copyToClipboard(config.venueAddress, '📍 Manzil muvaffaqiyatli nusxalandi!');
    });
  }

  const copyCardBtn = document.getElementById('copy-card-btn');
  if (copyCardBtn) {
    copyCardBtn.addEventListener('click', () => {
      const cardNum = config.cardNumber.replace(/\s+/g, '');
      copyToClipboard(cardNum, '💳 Karta raqami nusxalandi!');
    });
  }

  // -------------------------------------------------------------
  // 5. RSVP FORM & GUESTBOOK WISHES WALL
  // -------------------------------------------------------------
  const rsvpForm = document.getElementById('rsvp-form');
  const rsvpSuccess = document.getElementById('rsvp-success');
  const rsvpResetBtn = document.getElementById('rsvp-reset-btn');
  const radioCards = document.querySelectorAll('.radio-card');
  const guestbookFeed = document.getElementById('guestbook-feed');
  const guestsCountGroup = document.getElementById('guests-count-group');

  let userLikedWishes = [];
  try {
    userLikedWishes = JSON.parse(localStorage.getItem('taklifnoma_liked_wishes') || '[]');
  } catch (e) { userLikedWishes = []; }

  radioCards.forEach(card => {
    card.addEventListener('click', () => {
      radioCards.forEach(c => c.classList.remove('active'));
      card.classList.add('active');
      const radio = card.querySelector('input[type="radio"]');
      if (radio) {
        radio.checked = true;
        if (guestsCountGroup) {
          if (radio.value === 'no') {
            guestsCountGroup.style.display = 'none';
          } else {
            guestsCountGroup.style.display = 'block';
          }
        }
      }
    });
  });

  let wishesData = [
    {
      id: 1,
      author: 'Bekzod & Shahnoza',
      time: 'Bugun, 12:40',
      text: 'Shahzod va Dilorom, ikkovingizga ham dunyodagi eng oliy baxtni tilaymiz! Oila qo\'rg\'oningiz mustahkam, muhabbat bilingiz abadiy bo\'lsin!',
      likes: 14
    },
    {
      id: 2,
      author: 'Farrux Olimov',
      time: 'Kecha, 18:15',
      text: 'Qo\'sha qaringlar dostim! Baxtingizga ko\'z tegmasin, to\'yxonada uchrashguncha!',
      likes: 9
    },
    {
      id: 3,
      author: 'Dilshod aka va oilasi',
      time: '2 kun oldin',
      text: 'Yangi qurilayotgan oilangizga qut-baraka, totuvlik va ahillik hamrohingiz bo\'lishini tilab qolamiz. Tabriklaymiz!',
      likes: 18
    },
    {
      id: 4,
      author: 'Malika Begim',
      time: '3 kun oldin',
      text: 'Shahzoda va Malikadek bir-biriga munosib juftlik! Dunyodagi jamiki ezgu tilaklar sizlar uchun!',
      likes: 21
    }
  ];

  const savedWishes = localStorage.getItem('taklifnoma_wishes');
  if (savedWishes) {
    try {
      wishesData = JSON.parse(savedWishes);
    } catch (e) { console.error(e); }
  }

  function renderWishes() {
    if (!guestbookFeed) return;
    guestbookFeed.innerHTML = '';
    wishesData.forEach(wish => {
      const isLiked = userLikedWishes.includes(wish.id);
      const wishCard = document.createElement('div');
      wishCard.className = 'wish-card';
      wishCard.innerHTML = `
        <div class="wish-author">${escapeHtml(wish.author)}</div>
        <div class="wish-time">${escapeHtml(wish.time)}</div>
        <div class="wish-text">“${escapeHtml(wish.text)}”</div>
        <button class="wish-like-btn ${isLiked ? 'liked' : ''}" data-id="${wish.id}">
          <span class="heart-icon">${isLiked ? '💖' : '❤️'}</span>
          <span class="like-count">${wish.likes}</span>
        </button>
      `;
      guestbookFeed.appendChild(wishCard);
    });

    guestbookFeed.querySelectorAll('.wish-like-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = parseInt(btn.getAttribute('data-id'));
        const wish = wishesData.find(w => w.id === id);
        if (wish) {
          const index = userLikedWishes.indexOf(id);
          if (index > -1) {
            userLikedWishes.splice(index, 1);
            wish.likes = Math.max(0, wish.likes - 1);
            btn.classList.remove('liked');
            btn.querySelector('.heart-icon').textContent = '❤️';
          } else {
            userLikedWishes.push(id);
            wish.likes++;
            btn.classList.add('liked');
            btn.querySelector('.heart-icon').textContent = '💖';
          }
          const countSpan = btn.querySelector('.like-count');
          if (countSpan) countSpan.textContent = wish.likes;
          localStorage.setItem('taklifnoma_wishes', JSON.stringify(wishesData));
          localStorage.setItem('taklifnoma_liked_wishes', JSON.stringify(userLikedWishes));
        }
      });
    });
  }

  // -------------------------------------------------------------
  // RSVP DATA & ADMIN PANEL DASHBOARD ENGINE
  // -------------------------------------------------------------
  const defaultRsvpList = [
    { id: 101, name: 'Jasur & Nigora Bekmuradovlar', attendance: 'yes', count: '2 kishi (Juftlikda)', numGuests: 2, wish: 'Baxtli va saodatli oilalardan bo\'linglar!', date: 'Okt 04, 16:30' },
    { id: 102, name: 'Alisher Rustamov', attendance: 'yes', count: '1 kishi (Shaxsan o\'zim)', numGuests: 1, wish: 'Qutlug\' bo\'lsin to\'yingiz!', date: 'Okt 04, 16:45' },
    { id: 103, name: 'Sardor Sobirov', attendance: 'yes', count: 'Oila bilan (3+)', numGuests: 4, wish: 'Quyoshdek nurli oila qurishingizni tilayman.', date: 'Okt 04, 17:00' },
    { id: 104, name: 'Malika Oripova', attendance: 'no', count: '0 kishi', numGuests: 0, wish: 'Afsuski xizmat safaridaman, chin dildan tabriklayman!', date: 'Okt 04, 17:15' }
  ];

  let rsvpList = [];
  const savedRsvp = localStorage.getItem('taklifnoma_rsvp_list');
  if (savedRsvp) {
    try { rsvpList = JSON.parse(savedRsvp); } catch(e) { rsvpList = defaultRsvpList; }
  } else {
    rsvpList = defaultRsvpList;
    localStorage.setItem('taklifnoma_rsvp_list', JSON.stringify(rsvpList));
  }

  const adminModal = document.getElementById('admin-modal');
  const openAdminBtn = document.getElementById('open-admin-btn');
  const footerAdminBtn = document.getElementById('footer-admin-btn');
  const adminCloseBtn = document.getElementById('admin-close-btn');

  const statTotalGuests = document.getElementById('stat-total-guests');
  const statYesCount = document.getElementById('stat-yes-count');
  const statNoCount = document.getElementById('stat-no-count');
  const statWishesCount = document.getElementById('stat-wishes-count');

  const rsvpCountBadge = document.getElementById('rsvp-count-badge');
  const wishesCountBadge = document.getElementById('wishes-count-badge');
  const adminRsvpTbody = document.getElementById('admin-rsvp-tbody');
  const adminWishesContainer = document.getElementById('admin-wishes-container');

  const btnExportCsv = document.getElementById('btn-export-csv');
  const btnClearRsvp = document.getElementById('btn-clear-rsvp');

  // Tabs logic
  const adminTabBtns = document.querySelectorAll('.admin-tab-btn');
  const adminTabContents = document.querySelectorAll('.admin-tab-content');

  adminTabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      adminTabBtns.forEach(b => b.classList.remove('active'));
      adminTabContents.forEach(c => c.classList.remove('active'));

      btn.classList.add('active');
      const targetTab = btn.getAttribute('data-tab');
      const targetContent = document.getElementById(targetTab);
      if (targetContent) targetContent.classList.add('active');
    });
  });

  function renderAdminPanel() {
    const totalYesRSVPs = rsvpList.filter(r => r.attendance === 'yes').length;
    const totalNoRSVPs = rsvpList.filter(r => r.attendance === 'no').length;
    const totalGuestsSum = rsvpList.reduce((sum, r) => sum + (r.numGuests || 0), 0);
    const totalWishes = wishesData ? wishesData.length : 0;

    if (statTotalGuests) statTotalGuests.textContent = totalGuestsSum;
    if (statYesCount) statYesCount.textContent = totalYesRSVPs;
    if (statNoCount) statNoCount.textContent = totalNoRSVPs;
    if (statWishesCount) statWishesCount.textContent = totalWishes;

    if (rsvpCountBadge) rsvpCountBadge.textContent = rsvpList.length;
    if (wishesCountBadge) wishesCountBadge.textContent = totalWishes;

    // Render RSVP Table
    if (adminRsvpTbody) {
      if (!rsvpList.length) {
        adminRsvpTbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted" style="padding: 20px;">Hali hech kim tashrifni tasdiqlamadi</td></tr>';
      } else {
        adminRsvpTbody.innerHTML = rsvpList.map((item, idx) => `
          <tr>
            <td><strong>${idx + 1}</strong></td>
            <td><strong>${escapeHtml(item.name)}</strong></td>
            <td>
              ${item.attendance === 'yes'
                ? '<span class="badge-status badge-status-yes">✅ Keladi</span>'
                : '<span class="badge-status badge-status-no">❌ Borolmaydi</span>'}
            </td>
            <td>${escapeHtml(item.count || '1 kishi')}</td>
            <td>${escapeHtml(item.wish || '-')}</td>
            <td><small>${escapeHtml(item.date || '')}</small></td>
            <td>
              <button class="btn-delete-row" data-id="${item.id}">🗑️ O'chirish</button>
            </td>
          </tr>
        `).join('');

        adminRsvpTbody.querySelectorAll('.btn-delete-row').forEach(b => {
          b.addEventListener('click', (e) => {
            const id = parseInt(e.target.getAttribute('data-id'));
            rsvpList = rsvpList.filter(r => r.id !== id);
            localStorage.setItem('taklifnoma_rsvp_list', JSON.stringify(rsvpList));
            renderAdminPanel();
            showToast('🗑️ Yozuv o\'chirildi');
          });
        });
      }
    }

    // Render Wishes Container in Admin
    if (adminWishesContainer) {
      if (!wishesData || !wishesData.length) {
        adminWishesContainer.innerHTML = '<p class="text-center text-muted" style="padding: 20px;">Tilaklar hali kiritilmagan</p>';
      } else {
        adminWishesContainer.innerHTML = wishesData.map(w => `
          <div class="admin-wish-card">
            <div class="wish-content">
              <strong>${escapeHtml(w.author)}</strong> <small>(${escapeHtml(w.time)})</small>
              <p>“${escapeHtml(w.text)}”</p>
            </div>
            <button class="btn-delete-row" data-wish-id="${w.id}">🗑️ O'chirish</button>
          </div>
        `).join('');

        adminWishesContainer.querySelectorAll('.btn-delete-row').forEach(b => {
          b.addEventListener('click', (e) => {
            const id = parseInt(e.target.getAttribute('data-wish-id'));
            wishesData = wishesData.filter(w => w.id !== id);
            localStorage.setItem('taklifnoma_wishes', JSON.stringify(wishesData));
            renderWishes();
            renderAdminPanel();
            showToast('🗑️ Tilak o\'chirildi');
          });
        });
      }
    }
  }

  const VALID_ADMIN_LOGINS = ['abdurahmonovahrorbek666@gmail.com', 'abdurahmonovahrorbek666', 'admin', 'ahror', 'ahrorbek'];
  const VALID_ADMIN_PASSES = ['ahrorbek662', 'admin', '7777', '1234'];

  const adminLoginModal = document.getElementById('admin-login-modal');
  const adminLoginCloseBtn = document.getElementById('admin-login-close-btn');
  const adminLoginForm = document.getElementById('admin-login-form');
  const adminEmailInput = document.getElementById('admin-email');
  const adminPasswordInput = document.getElementById('admin-password');
  const adminLoginError = document.getElementById('admin-login-error');
  const adminLogoutBtn = document.getElementById('admin-logout-btn');

  function openAdminModal() {
    const isAuth = sessionStorage.getItem('taklifnoma_admin_auth') === 'true';
    if (!isAuth) {
      if (adminEmailInput) adminEmailInput.value = '';
      if (adminPasswordInput) adminPasswordInput.value = '';
      if (adminLoginError) adminLoginError.classList.add('hidden');
      if (adminLoginModal) adminLoginModal.classList.add('show');
    } else {
      renderAdminPanel();
      if (adminModal) adminModal.classList.add('show');
    }
  }

  if (adminLoginForm) {
    adminLoginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const emailVal = adminEmailInput ? adminEmailInput.value.trim().toLowerCase() : '';
      const passVal = adminPasswordInput ? adminPasswordInput.value.trim() : '';

      const isValidLogin = VALID_ADMIN_LOGINS.includes(emailVal);
      const isValidPass = VALID_ADMIN_PASSES.includes(passVal);

      if (isValidLogin && isValidPass) {
        sessionStorage.setItem('taklifnoma_admin_auth', 'true');
        if (adminLoginError) adminLoginError.classList.add('hidden');
        if (adminLoginModal) adminLoginModal.classList.remove('show');
        renderAdminPanel();
        if (adminModal) adminModal.classList.add('show');
        showToast('🔐 Admin panelliga muvaffaqiyatli kirdingiz!');
      } else {
        if (adminLoginError) adminLoginError.classList.remove('hidden');
      }
    });
  }

  if (adminLoginCloseBtn) {
    adminLoginCloseBtn.addEventListener('click', () => {
      if (adminLoginModal) adminLoginModal.classList.remove('show');
    });
  }
  if (adminLoginModal) {
    adminLoginModal.addEventListener('click', (e) => {
      if (e.target === adminLoginModal || e.target.classList.contains('admin-modal-backdrop')) {
        adminLoginModal.classList.remove('show');
      }
    });
  }

  if (adminLogoutBtn) {
    adminLogoutBtn.addEventListener('click', () => {
      sessionStorage.removeItem('taklifnoma_admin_auth');
      if (adminModal) adminModal.classList.remove('show');
      showToast('🚪 Admin paneldan chiqildi');
    });
  }

  if (openAdminBtn) openAdminBtn.addEventListener('click', openAdminModal);
  if (footerAdminBtn) footerAdminBtn.addEventListener('click', openAdminModal);
  if (adminCloseBtn) {
    adminCloseBtn.addEventListener('click', () => {
      if (adminModal) adminModal.classList.remove('show');
    });
  }
  if (adminModal) {
    adminModal.addEventListener('click', (e) => {
      if (e.target === adminModal || e.target.classList.contains('admin-modal-backdrop')) {
        adminModal.classList.remove('show');
      }
    });
  }

  // CSV Export functionality (Universal Excel CSV with UTF-8 BOM)
  if (btnExportCsv) {
    btnExportCsv.addEventListener('click', () => {
      if (!rsvpList.length) {
        showToast('⚠️ Yuklab olish uchun ma\'lumot yo\'q!');
        return;
      }
      let csvContent = '\uFEFF"№","Mehmon Ismi","Holati","Kishi Soni","Tilak","Sana"\n';
      rsvpList.forEach((r, i) => {
        const status = r.attendance === 'yes' ? 'Keladi' : 'Borolmaydi';
        const name = (r.name || '').replace(/"/g, '""');
        const count = (r.count || '').replace(/"/g, '""');
        const wish = (r.wish || '').replace(/"/g, '""').replace(/\r?\n/g, ' ');
        const date = (r.date || '').replace(/"/g, '""');
        csvContent += `"${i + 1}","${name}","${status}","${count}","${wish}","${date}"\n`;
      });

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `Taklifnoma_Mehmonlar_Royxati.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      showToast('📥 Mehmonlar ro\'yxati Excel (CSV) faylda yuklab olindi!');
    });
  }

  // Clear RSVP list
  if (btnClearRsvp) {
    btnClearRsvp.addEventListener('click', () => {
      if (confirm('Haqiqatan ham barcha mehmonlar ro\'yxatini tozalashni xohlaysizmi?')) {
        rsvpList = [];
        localStorage.setItem('taklifnoma_rsvp_list', JSON.stringify(rsvpList));
        renderAdminPanel();
        showToast('🗑️ Ro\'yxat tozalandi');
      }
    });
  }

  // Keyboard accessibility: Close modals on ESC key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (adminLoginModal) adminLoginModal.classList.remove('show');
      if (adminModal) adminModal.classList.remove('show');
      if (creatorModal) creatorModal.classList.remove('show');
      if (lightboxModal) lightboxModal.classList.remove('show');
    }
  });

  renderWishes();

  if (rsvpForm) {
    rsvpForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const nameInput = document.getElementById('guest-name');
      const wishInput = document.getElementById('guest-wish');
      const guestName = nameInput ? nameInput.value.trim() : '';
      const guestWish = wishInput ? wishInput.value.trim() : '';

      if (!guestName) {
        showToast('⚠️ Iltimos, ismingizni kiriting!');
        if (nameInput) nameInput.focus();
        return;
      }

      const attendanceRadio = document.querySelector('input[name="attendance"]:checked');
      const attendanceVal = attendanceRadio ? attendanceRadio.value : 'yes';
      const guestCountEl = document.getElementById('guest-count');
      const guestCountVal = guestCountEl ? guestCountEl.value : '1 kishi';

      let numGuests = 0;
      if (attendanceVal === 'yes') {
        if (guestCountVal.includes('3+')) numGuests = 3;
        else if (guestCountVal.includes('2')) numGuests = 2;
        else numGuests = 1;
      }

      const newRsvp = {
        id: Date.now(),
        name: guestName,
        attendance: attendanceVal,
        count: attendanceVal === 'yes' ? guestCountVal : '0 kishi',
        numGuests: numGuests,
        wish: guestWish,
        date: new Date().toLocaleString('uz', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
      };
      rsvpList.unshift(newRsvp);
      localStorage.setItem('taklifnoma_rsvp_list', JSON.stringify(rsvpList));

      if (guestWish) {
        const newWish = {
          id: Date.now(),
          author: guestName,
          time: 'Hozir',
          text: guestWish,
          likes: 1
        };
        wishesData.unshift(newWish);
        localStorage.setItem('taklifnoma_wishes', JSON.stringify(wishesData));
        renderWishes();
      }

      renderAdminPanel();

      rsvpForm.classList.add('hidden');
      rsvpSuccess.classList.remove('hidden');
      createConfettiExplosion();
      showToast('💖 Javobingiz muvaffaqiyatli saqlandi!');
    });
  }

  if (rsvpResetBtn) {
    rsvpResetBtn.addEventListener('click', () => {
      rsvpSuccess.classList.add('hidden');
      rsvpForm.classList.remove('hidden');
      rsvpForm.reset();
    });
  }

  // -------------------------------------------------------------
  // 6. INVITATION CREATOR MODAL, DEMO PRESETS & SHARE LINK GENERATOR
  // -------------------------------------------------------------
  const creatorModal = document.getElementById('creator-modal');
  const openCreatorBtn = document.getElementById('open-creator-btn');
  const creatorCloseBtn = document.getElementById('creator-close-btn');
  const creatorForm = document.getElementById('creator-form');
  const creatorShareBox = document.getElementById('creator-share-box');
  const shareLinkUrl = document.getElementById('share-link-url');
  const copyShareLinkBtn = document.getElementById('copy-share-link-btn');
  const telegramShareBtn = document.getElementById('telegram-share-btn');
  const previewCustomBtn = document.getElementById('preview-custom-btn');

  const inputGroom = document.getElementById('create-groom');
  const inputBride = document.getElementById('create-bride');
  const inputDate = document.getElementById('create-date');
  const inputVenue = document.getElementById('create-venue');
  const inputAddress = document.getElementById('create-address');
  const inputMap = document.getElementById('create-map');
  const inputCard = document.getElementById('create-card');
  const inputHolder = document.getElementById('create-holder');
  const schedContainer = document.getElementById('schedule-builder-container');
  const btnAddSchedRow = document.getElementById('btn-add-schedule-row');

  function renderScheduleInputs(schedList) {
    if (!schedContainer) return;
    const list = schedList && schedList.length ? schedList : [
      { time: '17:00', title: 'Mehmonlarni kutib olish', desc: 'Tantanali marosim va musiqiy sadolar' }
    ];
    schedContainer.innerHTML = list.map((item) => `
      <div class="schedule-builder-row">
        <div class="sched-row-time">
          <input type="text" class="sched-input-time" placeholder="17:00" value="${escapeHtml(item.time || '')}">
        </div>
        <div class="sched-row-details">
          <input type="text" class="sched-input-title" placeholder="Tadbir nomi (masalan: Mehmonlarni kutib olish)" value="${escapeHtml(item.title || '')}">
          <input type="text" class="sched-input-desc" placeholder="Tavsif (masalan: Tantanali marosim)" value="${escapeHtml(item.desc || '')}">
        </div>
        <button type="button" class="sched-remove-btn" title="O'chirish">&times;</button>
      </div>
    `).join('');

    schedContainer.querySelectorAll('.sched-remove-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const row = e.target.closest('.schedule-builder-row');
        if (row) row.remove();
      });
    });
  }

  if (btnAddSchedRow) {
    btnAddSchedRow.addEventListener('click', () => {
      if (!schedContainer) return;
      const newRow = document.createElement('div');
      newRow.className = 'schedule-builder-row';
      newRow.innerHTML = `
        <div class="sched-row-time">
          <input type="text" class="sched-input-time" placeholder="19:00" value="">
        </div>
        <div class="sched-row-details">
          <input type="text" class="sched-input-title" placeholder="Tadbir nomi" value="">
          <input type="text" class="sched-input-desc" placeholder="Qisqacha tavsif" value="">
        </div>
        <button type="button" class="sched-remove-btn" title="O'chirish">&times;</button>
      `;
      newRow.querySelector('.sched-remove-btn').addEventListener('click', () => {
        newRow.remove();
      });
      schedContainer.appendChild(newRow);
    });
  }

  function getScheduleFromInputs() {
    if (!schedContainer) return config.schedule;
    const rows = schedContainer.querySelectorAll('.schedule-builder-row');
    const newSched = [];
    rows.forEach(r => {
      const timeInput = r.querySelector('.sched-input-time');
      const titleInput = r.querySelector('.sched-input-title');
      const descInput = r.querySelector('.sched-input-desc');
      const time = timeInput ? timeInput.value.trim() : '';
      const title = titleInput ? titleInput.value.trim() : '';
      const desc = descInput ? descInput.value.trim() : '';
      if (time || title) {
        newSched.push({ time, title, desc });
      }
    });
    return newSched;
  }

  function populateCreatorForm() {
    if (inputGroom) inputGroom.value = config.groom;
    if (inputBride) inputBride.value = config.bride;
    if (inputDate) inputDate.value = config.dateIso;
    if (inputVenue) inputVenue.value = config.venueName;
    if (inputAddress) inputAddress.value = config.venueAddress;
    if (inputMap) inputMap.value = config.mapUrl || '';
    if (inputCard) inputCard.value = config.cardNumber;
    if (inputHolder) inputHolder.value = config.cardHolder;

    renderScheduleInputs(config.schedule);
  }

  function openCreatorModal() {
    populateCreatorForm();
    if (creatorShareBox) creatorShareBox.classList.add('hidden');
    if (creatorForm) creatorForm.classList.remove('hidden');
    if (creatorModal) creatorModal.classList.add('show');
    if (window.setModalActive) window.setModalActive(true);
  }

  function closeCreatorModal() {
    if (creatorModal) creatorModal.classList.remove('show');
    if (window.setModalActive) window.setModalActive(false);
  }

  if (openCreatorBtn) openCreatorBtn.addEventListener('click', openCreatorModal);
  
  const creatorBadge = document.querySelector('.creator-badge');
  const creatorText = document.querySelector('.creator-text');
  if (creatorBadge) creatorBadge.addEventListener('click', openCreatorModal);
  if (creatorText) creatorText.addEventListener('click', openCreatorModal);

  // Demo Preset Buttons (1-click sample preview)
  document.querySelectorAll('.demo-preset-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const groom = btn.getAttribute('data-groom') || 'Shahzod';
      const bride = btn.getAttribute('data-bride') || 'Dilorom';
      const venue = btn.getAttribute('data-venue') || '“Oq Saroy” Tantanalar Saroyi';
      const address = btn.getAttribute('data-address') || 'Toshkent shahri';
      const date = btn.getAttribute('data-date') || '2026-10-17T17:00';

      if (inputGroom) inputGroom.value = groom;
      if (inputBride) inputBride.value = bride;
      if (inputVenue) inputVenue.value = venue;
      if (inputAddress) inputAddress.value = address;
      if (inputDate) inputDate.value = date;

      config.groom = groom;
      config.bride = bride;
      config.coupleNames = `${groom} & ${bride}`;
      config.venueName = venue;
      config.venueAddress = address;
      config.dateIso = date;

      if (groom === 'Jasur') {
        config.schedule = [
          { time: '18:00', title: 'Mehmonlarni kutib olish', desc: 'Versal saroyi fayerida tantanali kutib olish' },
          { time: '19:00', title: 'Kelin-kuyov kelishi & Nikoh', desc: 'Tantanali kirib kelish marosimi' },
          { time: '20:00', title: 'Shohona Ziyofat & Qutlovlar', desc: 'Dasturxon va samimiy tilaklar' },
          { time: '22:00', title: 'Raqs & Tort', desc: 'Musiqiy shou hamda to\'y tortini kesish' }
        ];
      } else if (groom === 'Sardor') {
        config.schedule = [
          { time: '17:30', title: 'Mehmonlar tashrifi', desc: 'Yulduz restorani kutib olish marosimi' },
          { time: '18:30', title: 'Nikoh marosimi', desc: 'Kelin va kuyovning tantanali kirib kelishi' },
          { time: '19:30', title: 'Bayramona kecha', desc: 'San\'atkorlar ijrosi va qutlovlar' },
          { time: '21:30', title: 'Shirinliklar & Tort', desc: 'To\'y torti marosimi' }
        ];
      } else {
        config.schedule = [
          { time: '17:00', title: 'Mehmonlarni kutib olish', desc: 'To\'yxona fayerida tantanali kutib olish marosimi va musiqiy sadolar' },
          { time: '18:00', title: 'Kelin-kuyov kelishi & Nikoh', desc: 'Tantanali kirib kelish va nikoh to\'yining ochilishi' },
          { time: '19:00', title: 'Shohona Ziyofat & Qutlovlar', desc: 'Yaqinlar va mehmonlarning samimiy tilaklari hamda dasturxon' },
          { time: '21:00', title: 'Jonli Ijro, Raqs & Tort', desc: 'El suygan san\'atkorlar ijrosi va bayramona to\'y tortini kesish' }
        ];
      }

      applyConfigToDOM();
      updateCountdown();

      closeCreatorModal();
      if (envelopeModal) {
        envelopeModal.classList.add('closed');
        envelopeModal.classList.remove('closing');
        envelopeModal.style.display = 'none';
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
      try { createConfettiExplosion(); } catch(err) {}
      showToast(`✨ Namuna kiritildi va ochildi: ${groom} & ${bride}`);
    });
  });

  if (creatorCloseBtn) {
    creatorCloseBtn.addEventListener('click', closeCreatorModal);
  }

  if (creatorModal) {
    creatorModal.addEventListener('click', (e) => {
      if (e.target === creatorModal || e.target.classList.contains('creator-modal-backdrop')) {
        closeCreatorModal();
      }
    });
  }

  function buildShareableUrl() {
    let origin = window.location.origin;
    let pathname = window.location.pathname || '/';

    // Vercel preview yoki vaqtinchalik domenlarni toza asosiy manzilga o'girish
    const host = window.location.hostname;
    if (host.includes('vercel.app')) {
      if (host.includes('taklifnomaweb') || host.includes('webtaklifnoma')) {
        origin = 'https://webtaklifnoma-taklifnomaweb.vercel.app';
        pathname = '/';
      }
    } else if (origin === 'null' || !origin || origin.startsWith('file:') || host === 'localhost' || host === '127.0.0.1') {
      origin = 'https://webtaklifnoma-taklifnomaweb.vercel.app';
      pathname = '/';
    }

    // index.html ni olib tashlash
    pathname = pathname.replace(/\/index\.html$/i, '/');
    if (!pathname.endsWith('/')) {
      pathname = pathname + '/';
    }

    const baseUrl = origin + pathname;
    const params = new URLSearchParams();
    if (config.groom) params.set('groom', config.groom);
    if (config.bride) params.set('bride', config.bride);
    if (config.dateIso) params.set('date', config.dateIso);
    if (config.venueName) params.set('venue', config.venueName);
    if (config.venueAddress) params.set('address', config.venueAddress);
    if (config.cardNumber) params.set('card', config.cardNumber);
    if (config.cardHolder) params.set('holder', config.cardHolder);
    if (config.mapUrl) params.set('map', config.mapUrl);
    if (config.schedule && config.schedule.length) {
      try {
        params.set('sched', JSON.stringify(config.schedule));
      } catch (err) {}
    }
    const fullUrl = `${baseUrl}?${params.toString()}`;
    try {
      window.history.replaceState({ custom: true }, '', fullUrl);
    } catch(e) {}
    return fullUrl;
  }

  function updateShareBoxData() {
    const generatedUrl = buildShareableUrl();
    if (shareLinkUrl) shareLinkUrl.value = generatedUrl;

    const shareText = `Sizni nikoh to'yimiz munosabati bilan bo'lib o'tadigan "Visol oqshomi"ga taklif etamiz! 💍✨\nKelin-kuyov: ${config.coupleNames}\nSana: ${config.dateFormatted}`;

    if (telegramShareBtn) {
      telegramShareBtn.href = `https://t.me/share/url?url=${encodeURIComponent(generatedUrl)}&text=${encodeURIComponent(shareText)}`;
    }
    const whatsappShareBtn = document.getElementById('whatsapp-share-btn');
    if (whatsappShareBtn) {
      whatsappShareBtn.href = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText + '\n' + generatedUrl)}`;
    }
    return generatedUrl;
  }

  function openShareModal() {
    const generatedUrl = updateShareBoxData();
    if (creatorForm) creatorForm.classList.add('hidden');
    if (creatorShareBox) creatorShareBox.classList.remove('hidden');
    if (creatorModal) creatorModal.classList.add('show');
    copyToClipboard(generatedUrl, '📋 Taklifnoma havolasi nusxalandi! Telegram yoki boshqa ilovalar orqali yuborishingiz mumkin.');
  }

  const topShareBtn = document.getElementById('top-share-btn');
  const floatingShareBtn = document.getElementById('floating-share-btn');
  if (topShareBtn) topShareBtn.addEventListener('click', openShareModal);
  if (floatingShareBtn) floatingShareBtn.addEventListener('click', openShareModal);

  function saveFormDataToConfig() {
    const newGroom = inputGroom ? inputGroom.value.trim() : config.groom;
    const newBride = inputBride ? inputBride.value.trim() : config.bride;
    const newDate = inputDate ? inputDate.value : config.dateIso;
    const newVenue = inputVenue ? inputVenue.value.trim() : config.venueName;
    const newAddress = inputAddress ? inputAddress.value.trim() : config.venueAddress;
    const newMap = inputMap ? inputMap.value.trim() : (config.mapUrl || '');
    const newCard = inputCard ? (inputCard.value.trim() || config.cardNumber) : config.cardNumber;
    const newHolder = inputHolder ? (inputHolder.value.trim() || config.cardHolder) : config.cardHolder;
    const newSchedule = getScheduleFromInputs();

    config.groom = newGroom || 'Shahzod';
    config.bride = newBride || 'Dilorom';
    config.coupleNames = `${config.groom} & ${config.bride}`;
    config.dateIso = newDate;
    config.venueName = newVenue || '“Oq Saroy” Tantanalar Saroyi';
    config.venueAddress = newAddress || 'Toshkent shahri';
    config.mapUrl = newMap;
    config.cardNumber = newCard;
    config.cardHolder = newHolder;
    config.schedule = newSchedule;

    // localStorage ga saqlamaymiz — faqat URL orqali ulashiladi

    applyConfigToDOM();
    updateCountdown();
  }

  function handleCreateAndShowInvitation(e) {
    if (e) e.preventDefault();

    saveFormDataToConfig();

    // 1. Instantly close the creator modal
    closeCreatorModal();

    // 2. Instantly close & hide the envelope modal so invitation is 100% visible
    if (envelopeModal) {
      envelopeModal.classList.add('closed');
      envelopeModal.classList.remove('closing');
      envelopeModal.style.display = 'none';
    }

    // 3. Smoothly scroll to the top of the newly generated invitation
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // 4. Celebrate with confetti explosion
    try { createConfettiExplosion(); } catch(err) {}

    // 5. Play audio or fallback synth if not already playing
    try { window.playAudioGlobal(); } catch(err) {}

    // 6. Show celebratory notification
    showToast(`🎉 Taklifnomangiz muvaffaqiyatli yaratildi va ochildi: ${config.coupleNames}!`);

    // Prepare share data in background
    setTimeout(() => { updateShareBoxData(); }, 50);
  }

  if (creatorForm) {
    creatorForm.addEventListener('submit', handleCreateAndShowInvitation);
  }

  // "HAVOLANI OLISH" button inside creator modal form
  const creatorGetLinkBtn = document.getElementById('creator-get-link-btn');
  if (creatorGetLinkBtn) {
    creatorGetLinkBtn.addEventListener('click', () => {
      saveFormDataToConfig();
      const generatedUrl = updateShareBoxData();
      if (creatorForm) creatorForm.classList.add('hidden');
      if (creatorShareBox) creatorShareBox.classList.remove('hidden');
      copyToClipboard(generatedUrl, `📋 Taklifnoma havolasi nusxalandi: ${config.coupleNames}!`);
    });
  }

  if (copyShareLinkBtn) {
    copyShareLinkBtn.addEventListener('click', () => {
      if (shareLinkUrl && shareLinkUrl.value) {
        copyToClipboard(shareLinkUrl.value, '📋 Taklifnoma havolasi nusxalandi!');
      } else {
        const url = updateShareBoxData();
        copyToClipboard(url, '📋 Taklifnoma havolasi nusxalandi!');
      }
    });
  }

  if (previewCustomBtn) {
    previewCustomBtn.addEventListener('click', () => {
      if (creatorModal) creatorModal.classList.remove('show');
      if (envelopeModal) {
        envelopeModal.classList.add('closed');
        envelopeModal.classList.remove('closing');
        envelopeModal.style.display = 'none';
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
      try { createConfettiExplosion(); } catch(err) {}
      showToast(`✨ Taklifnoma namoyish etilmoqda: ${config.coupleNames}`);
    });
  }

  const editCustomBtn = document.getElementById('edit-custom-btn');
  if (editCustomBtn) {
    editCustomBtn.addEventListener('click', () => {
      if (creatorShareBox) creatorShareBox.classList.add('hidden');
      if (creatorForm) creatorForm.classList.remove('hidden');
    });
  }

  // -------------------------------------------------------------
  // 7. LIGHTBOX GALLERY MODAL
  // -------------------------------------------------------------
  const galleryItems = document.querySelectorAll('.gallery-item');
  const lightboxModal = document.getElementById('lightbox-modal');
  const lightboxImg = document.getElementById('lightbox-img');
  const lightboxCaption = document.getElementById('lightbox-caption');
  const lightboxClose = document.getElementById('lightbox-close');

  galleryItems.forEach(item => {
    item.addEventListener('click', () => {
      const src = item.getAttribute('data-src') || item.querySelector('img').src;
      const captionText = item.querySelector('.gallery-caption')?.textContent || '';
      if (lightboxModal && lightboxImg) {
        lightboxImg.src = src;
        lightboxCaption.textContent = captionText;
        lightboxModal.classList.add('show');
      }
    });
  });

  if (lightboxClose) {
    lightboxClose.addEventListener('click', () => {
      lightboxModal.classList.remove('show');
    });
  }
  if (lightboxModal) {
    lightboxModal.addEventListener('click', (e) => {
      if (e.target === lightboxModal) {
        lightboxModal.classList.remove('show');
      }
    });
  }

  // -------------------------------------------------------------
  // 8. CANVAS FLOATING ROSE PETALS (OPTIMIZED HIGH PERFORMANCE)
  // -------------------------------------------------------------
  window.isModalActive = false;
  let petalsAnimId = null;

  window.setModalActive = function(active) {
    window.isModalActive = Boolean(active);
    if (active) {
      document.body.classList.add('modal-open');
    } else {
      document.body.classList.remove('modal-open');
      if (!petalsAnimId && canvas && !document.hidden) {
        petalsAnimId = requestAnimationFrame(animatePetals);
      }
    }
  };

  const canvas = document.getElementById('petals-canvas');
  if (canvas) {
    const ctx = canvas.getContext('2d');
    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    window.addEventListener('resize', () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    }, { passive: true });

    const isMobile = window.innerWidth < 768;
    const numPetals = isMobile ? 12 : 20;
    const petals = [];
    const colors = [
      'rgba(255, 182, 193, 0.7)',
      'rgba(255, 218, 185, 0.7)',
      'rgba(238, 203, 114, 0.7)',
      'rgba(255, 255, 255, 0.8)'
    ];

    for (let i = 0; i < numPetals; i++) {
      petals.push({
        x: Math.random() * width,
        y: Math.random() * height,
        size: Math.random() * 8 + 5,
        speedY: Math.random() * 0.22 + 0.1,
        speedX: Math.random() * 0.16 - 0.08,
        angle: Math.random() * 360,
        spin: Math.random() * 0.3 - 0.15,
        color: colors[i % colors.length]
      });
    }

    function animatePetals() {
      // Pause canvas rendering if modal is open or tab is hidden
      if (window.isModalActive || document.hidden) {
        petalsAnimId = null;
        return;
      }

      ctx.clearRect(0, 0, width, height);

      for (let i = 0; i < petals.length; i++) {
        const p = petals[i];
        p.y += p.speedY;
        p.x += p.speedX + Math.sin(p.y * 0.008) * 0.3;
        p.angle += p.spin;

        if (p.y > height + 20) {
          p.y = -20;
          p.x = Math.random() * width;
        }

        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate((p.angle * Math.PI) / 180);
        ctx.fillStyle = p.color;

        ctx.beginPath();
        ctx.moveTo(0, -p.size);
        ctx.bezierCurveTo(p.size * 0.8, -p.size * 0.5, p.size, p.size * 0.5, 0, p.size);
        ctx.bezierCurveTo(-p.size, p.size * 0.5, -p.size * 0.8, -p.size * 0.5, 0, -p.size);
        ctx.fill();
        ctx.restore();
      }

      petalsAnimId = requestAnimationFrame(animatePetals);
    }

    document.addEventListener('visibilitychange', () => {
      if (!document.hidden && !window.isModalActive && !petalsAnimId) {
        petalsAnimId = requestAnimationFrame(animatePetals);
      }
    });

    petalsAnimId = requestAnimationFrame(animatePetals);
  }

  function createConfettiExplosion() {
    window.createConfettiExplosion();
  }

  // -------------------------------------------------------------
  // 10. INTERACTIVE SPARKLE CURSOR (DESKTOP ONLY, MODAL SAFE)
  // -------------------------------------------------------------
  if (window.matchMedia && window.matchMedia('(pointer: fine)').matches) {
    let lastSparkleTime = 0;
    document.addEventListener('mousemove', (e) => {
      if (window.isModalActive) return;
      const now = Date.now();
      if (now - lastSparkleTime < 160) return;
      lastSparkleTime = now;

      const sparkle = document.createElement('div');
      sparkle.className = 'cursor-sparkle';
      const icons = ['✨', '🌟', '💖', '🌸', '✨'];
      sparkle.textContent = icons[Math.floor(Math.random() * icons.length)];
      sparkle.style.left = e.clientX + 'px';
      sparkle.style.top = e.clientY + 'px';
      sparkle.style.setProperty('--tx', (Math.random() * 30 - 15) + 'px');
      sparkle.style.setProperty('--ty', (-Math.random() * 30 - 10) + 'px');
      document.body.appendChild(sparkle);

      setTimeout(() => sparkle.remove(), 800);
    }, { passive: true });
  }

});
